import * as React from 'react';
import { Image } from "react-native";




const SmallIcon  = props =>  <Image  source={props.img}  style={{ width: 40 , height: 40}}/>


export default SmallIcon