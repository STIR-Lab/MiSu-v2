//export const setHubInfo = dataMsg => (
//  {
//    type: 'SET_HUB_INFO',
//    payload: dataMsg,
 // }

//);
//export const setAccountInfo = dataMsg => (
//  {
//    type: 'SET_ACCOUNT_INFO',
//    payload: dataMsg,
 // }
//);

export const setSharedAccounts = dataMsg => (
  {
    type: 'SET_SHARED_ACCOUNTS',
    payload: dataMsg,
  }
);

export const setSharedDevices = dataMsg => (
  {
    type: 'SET_SHARED_DEVICES',
    payload: dataMsg,
  }
);

  export const setDevices = dataMsg => (
    {
      type: 'SET_DEVICES',
      payload: dataMsg,
    }
);